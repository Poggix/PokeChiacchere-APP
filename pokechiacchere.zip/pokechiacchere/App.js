import React, { useCallback, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  ActivityIndicator, Alert, FlatList, Modal, SafeAreaView,
  ScrollView, StatusBar, StyleSheet, Text, TextInput,
  TouchableOpacity, View
} from 'react-native';

const URL = 'https://omovacbvfhmtjqrrgszx.supabase.co';
const KEY = 'sb_publishable_riYV0ro2BZo3umMa71mPGQ_mUPm4MA9';
const SOCI = ['Poggio', 'Fanton'];

const C = {
  bg: '#080D18', panel: '#111B2D', panel2: '#192943',
  blue: '#168BFF', cyan: '#55B5FF', red: '#FF334F',
  yellow: '#FFD43B', white: '#F5F8FF', muted: '#9BAAC2',
  green: '#4DDFAB', border: '#2B3D59'
};

const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};

const num = v => Number(String(v ?? 0).replace(',', '.')) || 0;

// Il database continua a ricevere date ISO (AAAA-MM-GG), mentre l'app le mostra in italiano.
const toItalianDate = value => {
  if (!value) return '';
  const match = String(value).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[3]}/${match[2]}/${match[1]}`;
  const italian = String(value).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  return italian ? value : String(value);
};
const toDatabaseDate = value => {
  if (!value) return today();
  const match = String(value).trim().match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (match) return `${match[3]}-${match[2]}-${match[1]}`;
  return String(value).trim();
};
const dateSortValue = value => {
  const iso = toDatabaseDate(value);
  const time = Date.parse(iso);
  return Number.isNaN(time) ? 0 : time;
};
const money = v => new Intl.NumberFormat('it-IT', {
  style: 'currency', currency: 'EUR'
}).format(num(v));

async function api(path, token, options = {}) {
  const response = await fetch(URL + path, {
    ...options,
    headers: {
      apikey: KEY,
      Authorization: `Bearer ${token || KEY}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });

  const text = await response.text();
  let result;
  try { result = text ? JSON.parse(text) : null; }
  catch { result = text; }

  if (!response.ok) {
    throw new Error(
      result?.message || result?.details || result?.hint ||
      String(result || 'Errore Supabase')
    );
  }
  return result;
}

function Button({ title, onPress, type = 'primary' }) {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      style={[
        s.button,
        type === 'secondary' && s.buttonSecondary,
        type === 'danger' && s.buttonDanger,
        type === 'success' && s.buttonSuccess
      ]}
    >
      <Text style={s.buttonText}>{title}</Text>
    </TouchableOpacity>
  );
}

function Field({ label, value, onChangeText, keyboardType, placeholder }) {
  return (
    <View style={s.field}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        style={s.input}
        value={String(value ?? '')}
        onChangeText={onChangeText}
        keyboardType={keyboardType || 'default'}
        placeholder={placeholder || label}
        placeholderTextColor={C.muted}
        autoCapitalize="sentences"
      />
    </View>
  );
}

function DropDown({ label, value, onPress, hint }) {
  return (
    <View style={s.field}>
      <Text style={s.label}>{label}</Text>
      <TouchableOpacity style={s.dropdown} onPress={onPress}>
        <Text style={[s.dropdownText, !value && { color: C.muted }]}>
          {value || hint || 'Seleziona'}
        </Text>
        <Text style={s.chevron}>⌄</Text>
      </TouchableOpacity>
    </View>
  );
}

function Card({ title, value, color = C.cyan, subtitle }) {
  return (
    <View style={s.metric}>
      <View style={[s.metricLine, { backgroundColor: color }]} />
      <Text style={s.metricLabel}>{title}</Text>
      <Text style={s.metricValue}>{money(value)}</Text>
      {!!subtitle && <Text style={s.mutedSmall}>{subtitle}</Text>}
    </View>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [listSearch, setListSearch] = useState('');
  const [sortMode, setSortMode] = useState('date_desc');
  const [listView, setListView] = useState('details');
  const [namePosition, setNamePosition] = useState('center');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState('home');
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(null);
  const [picker, setPicker] = useState(null);
  const [search, setSearch] = useState('');

  const [records, setRecords] = useState({
    sales: [], purchases: [], internal_payments: [],
    withdrawals: [], products: [], customers: []
  });

  const token = session?.access_token;
  const change = (key, value) =>
    setForm(old => ({ ...old, [key]: value }));

  const loadData = useCallback(async () => {
    if (!token) return;
    try {
      const tables = [
        'sales', 'purchases', 'internal_payments',
        'withdrawals', 'products', 'customers'
      ];
      // Se una tabella non ha created_at, la richiesta senza ordinamento evita di bloccare tutti gli archivi.
      const values = await Promise.all(tables.map(async table => {
        try {
          return await api(`/rest/v1/${table}?select=*&order=created_at.desc`, token);
        } catch (firstError) {
          try { return await api(`/rest/v1/${table}?select=*`, token); }
          catch { throw firstError; }
        }
      }));
      const next = {};
      tables.forEach((table, i) => { next[table] = Array.isArray(values[i]) ? values[i] : []; });
      setRecords(next);
    } catch (e) {
      // Se il token è scaduto, prova a rinnovarlo usando il refresh_token salvato.
      if (/JWT|token|expired|401/i.test(e.message || '') && session?.refresh_token) {
        try {
          const response = await fetch(`${URL}/auth/v1/token?grant_type=refresh_token`, {
            method: 'POST',
            headers: { apikey: KEY, 'Content-Type': 'application/json' },
            body: JSON.stringify({ refresh_token: session.refresh_token })
          });
          const renewed = await response.json();
          if (response.ok && renewed.access_token) {
            setSession(renewed);
            await AsyncStorage.setItem('pokechiacchere_session', JSON.stringify(renewed));
            return;
          }
        } catch (_) {}
        await AsyncStorage.removeItem('pokechiacchere_session').catch(() => {});
        setSession(null);
      }
      Alert.alert('Errore caricamento', e.message);
    }
  }, [token, session]);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem('pokechiacchere_session')
      .then(raw => {
        if (active && raw) {
          try { setSession(JSON.parse(raw)); }
          catch { AsyncStorage.removeItem('pokechiacchere_session'); }
        }
      })
      .catch(() => {})
      .finally(() => { if (active) setSessionReady(true); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (token) loadData();
  }, [token, loadData]);

  async function signOut() {
    await AsyncStorage.removeItem('pokechiacchere_session').catch(() => {});
    setSession(null);
    setPassword('');
    setPage('home');
    setForm({});
    setEditing(null);
    setPicker(null);
    setRecords({ sales: [], purchases: [], internal_payments: [], withdrawals: [], products: [], customers: [] });
  }

  async function signIn() {
    if (!email.trim() || !password) {
      Alert.alert('Accesso', 'Inserisci email e password.');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `${URL}/auth/v1/token?grant_type=password`,
        {
          method: 'POST',
          headers: {
            apikey: KEY,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email: email.trim(),
            password
          })
        }
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(
          data.error_description || data.message || 'Accesso non riuscito'
        );
      }
      setSession(data);
      await AsyncStorage.setItem('pokechiacchere_session', JSON.stringify(data));
    } catch (e) {
      Alert.alert('Errore di accesso', e.message);
    } finally {
      setLoading(false);
    }
  }

  function openForm(target, initial = {}) {
    setEditing(null);
    setForm({
      date: toItalianDate(today()),
      quantity: '1',
      unit_price: '0',
      amount: '',
      fees: '0',
      other_costs: '0',
      purchase_unit_cost: '0',
      ...initial
    });
    setPage(target);
  }

  function editRow(table, row) {
    setEditing({ table, id: row.id });

    setForm({
      ...row,
      date: toItalianDate(row.sale_date || row.purchase_date || row.payment_date || row.withdrawal_date || today()),
      quantity: String(row.quantity ?? '1'),
      unit_price: String(row.unit_price ?? row.sale_unit_price ?? '0'),
      amount: String(row.amount ?? '0'),
      fees: String(row.tiktok_fees ?? '0'),
      other_costs: String(row.other_costs ?? '0'),
      purchase_unit_cost: String(row.purchase_unit_cost ?? '0'),
      first_name: row.customer_first_name || '',
      last_name: row.customer_last_name || '',
      name: row.name || ''
    });

    const targets = {
      sales: 'saleForm',
      purchases: 'purchaseForm',
      internal_payments: 'paymentForm',
      withdrawals: 'withdrawalForm',
      products: 'products',
      customers: 'customers'
    };
    setPage(targets[table] || 'home');
  }

  async function saveRecord(table, data) {
    setLoading(true);

    try {
      if (editing?.table === table && editing?.id) {
        await api(
          `/rest/v1/${table}?id=eq.${encodeURIComponent(editing.id)}`,
          token,
          {
            method: 'PATCH',
            headers: { Prefer: 'return=minimal' },
            body: JSON.stringify(data)
          }
        );
      } else {
        await api(`/rest/v1/${table}`, token, {
          method: 'POST',
          headers: { Prefer: 'return=minimal' },
          body: JSON.stringify({
            ...data,
            created_by: session?.user?.id
          })
        });
      }

      setEditing(null);
      setForm({});
      await loadData();

      const targets = {
        sales: 'sales',
        purchases: 'purchases',
        internal_payments: 'payments',
        withdrawals: 'withdrawals'
      };
      setPage(targets[table] || 'home');
      Alert.alert('Salvato', 'Registrazione salvata.');
    } catch (e) {
      Alert.alert('Salvataggio non riuscito', e.message);
    } finally {
      setLoading(false);
    }
  }

  async function addCatalog(table, value) {
    const name = String(value || '').trim();
    if (!name) return;

    const existing = records[table].some(
      row => String(row.name || '').toLowerCase() === name.toLowerCase()
    );
    if (existing) return;

    const payload = { name };
    await api(`/rest/v1/${table}`, token, {
      method: 'POST',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify(payload)
    });
    await loadData();
  }

  async function saveSale() {
    const product = String(form.product || '').trim();
    const first = String(form.first_name || '').trim();
    const last = String(form.last_name || '').trim();
    const quantity = num(form.quantity);
    const price = num(form.unit_price);
    const total = quantity * price;
    const productCost = quantity * num(form.purchase_unit_cost);

    if (!product || quantity <= 0 || price < 0) {
      Alert.alert('Dati mancanti', 'Controlla prodotto, quantità e prezzo.');
      return;
    }

    setLoading(true);
    try {
      await addCatalog('products', product);

      const customer = [first, last].filter(Boolean).join(' ');
      if (customer) await addCatalog('customers', customer);

      const data = {
        sale_date: toDatabaseDate(form.date),
        order_number: form.order_number || '',
        customer_name: customer,
        customer_first_name: first || null,
        customer_last_name: last || null,
        product,
        quantity,
        sale_unit_price: price,
        unit_price: price,
        total_sale: total,
        tiktok_fees: num(form.fees),
        other_costs: num(form.other_costs),
        purchase_unit_cost: num(form.purchase_unit_cost),
        product_cost: productCost,
        net_profit: total - num(form.fees) -
          num(form.other_costs) - productCost,
        flat_tax: total * 0.02
      };

      await saveRecord('sales', data);
    } catch (e) {
      Alert.alert('Errore vendita', e.message);
      setLoading(false);
    }
  }

  async function savePurchase() {
    const product = String(form.product || '').trim();
    const buyer = String(form.buyer || '').trim();
    const quantity = num(form.quantity);
    const price = num(form.unit_price);

    if (!product || !buyer || quantity <= 0 || price < 0) {
      Alert.alert('Dati mancanti', 'Inserisci socio, prodotto e quantità.');
      return;
    }

    try {
      await addCatalog('products', product);
      await saveRecord('purchases', {
        purchase_date: toDatabaseDate(form.date),
        buyer,
        product,
        quantity,
        unit_price: price
      });
    } catch (e) {
      Alert.alert('Errore acquisto', e.message);
      setLoading(false);
    }
  }

  async function deleteRow(table, row) {
    Alert.alert(
      'Eliminare la registrazione?',
      'L’operazione non si può annullare.',
      [
        { text: 'Annulla', style: 'cancel' },
        {
          text: 'Elimina',
          style: 'destructive',
          onPress: async () => {
            setLoading(true);
            try {
              await api(
                `/rest/v1/${table}?id=eq.${encodeURIComponent(row.id)}`,
                token,
                { method: 'DELETE' }
              );
              await loadData();
            } catch (e) {
              Alert.alert('Errore eliminazione', e.message);
            } finally {
              setLoading(false);
            }
          }
        }
      ]
    );
  }

  const totals = useMemo(() => {
    const sales = records.sales.reduce(
      (sum, r) => sum + num(r.total_sale || num(r.quantity) * num(r.unit_price || r.sale_unit_price)), 0
    );

    const fees = records.sales.reduce((sum, r) => sum + num(r.tiktok_fees), 0);
    const other = records.sales.reduce((sum, r) => sum + num(r.other_costs), 0);
    const cost = records.sales.reduce(
      (sum, r) => sum + num(r.product_cost ?? num(r.quantity) * num(r.purchase_unit_cost)), 0
    );
    const tax = records.sales.reduce((sum, r) => sum + num(r.flat_tax), 0);
    const profitBeforeTax = sales - fees - other - cost;
    const profit = profitBeforeTax - tax;

    const purchases = records.purchases.reduce(
      (sum, r) => sum + num(r.quantity) * num(r.unit_price), 0
    );

    const purchaseBy = person => records.purchases
      .filter(r => r.buyer === person)
      .reduce((sum, r) => sum + num(r.quantity) * num(r.unit_price), 0);

    const withdrawals = person => records.withdrawals
      .filter(r => r.person === person)
      .reduce((sum, r) => sum + num(r.amount), 0);

    const paymentsMade = person => records.internal_payments
      .filter(r => r.payer === person)
      .reduce((sum, r) => sum + num(r.amount), 0);

    const paymentsReceived = person => records.internal_payments
      .filter(r => r.receiver === person)
      .reduce((sum, r) => sum + num(r.amount), 0);

    const halfProfit = profit / 2;

    // Stima del saldo tra soci: acquisti anticipati + quota utile
    // meno prelievi e pagamenti ricevuti, più pagamenti effettuati.
    const balance = person =>
      purchaseBy(person) + halfProfit - withdrawals(person) -
      paymentsReceived(person) + paymentsMade(person);

    const poggioBalance = balance('Poggio');
    const fantonBalance = balance('Fanton');

    return {
      sales, fees, other, cost, tax, profitBeforeTax, profit,
      purchases,
      poggioPurchases: purchaseBy('Poggio'),
      fantonPurchases: purchaseBy('Fanton'),
      poggioWithdrawals: withdrawals('Poggio'),
      fantonWithdrawals: withdrawals('Fanton'),
      poggioBalance, fantonBalance,
      poggioPosition: halfProfit - withdrawals('Poggio'),
      fantonPosition: halfProfit - withdrawals('Fanton'),
      paymentsMadeP: paymentsMade('Poggio'),
      paymentsMadeF: paymentsMade('Fanton'),
      paymentsReceivedP: paymentsReceived('Poggio'),
      paymentsReceivedF: paymentsReceived('Fanton'),
      cashEstimate: sales - fees - other - purchases -
        records.withdrawals.reduce((sum, r) => sum + num(r.amount), 0)
    };
  }, [records]);

  function openPicker(type, key) {
    setSearch('');
    setPicker({ type, key });
  }

  function optionsForPicker() {
    if (!picker) return [];
    if (picker.type === 'product') return records.products.map(r => r.name);
    if (picker.type === 'customer') return records.customers.map(r => r.name);
    if (picker.type === 'partner') return SOCI;
    if (picker.type === 'receiver') return SOCI;
    return [];
  }

  function chooseOption(value) {
    if (!picker) return;

    if (picker.type === 'customer') {
      const parts = value.split(' ');
      change('first_name', parts.shift() || '');
      change('last_name', parts.join(' '));
    } else {
      change(picker.key, value);
    }

    setPicker(null);
    setSearch('');
  }

  function dropdown(label, type, key, value, hint) {
    return (
      <DropDown
        label={label}
        value={value}
        hint={hint}
        onPress={() => openPicker(type, key)}
      />
    );
  }

  function pickerModal() {
    const options = optionsForPicker().filter(value =>
      value.toLowerCase().includes(search.toLowerCase())
    );
    const isCatalog = picker?.type === 'product' || picker?.type === 'customer';

    return (
      <Modal
        visible={!!picker}
        transparent
        animationType="slide"
        onRequestClose={() => setPicker(null)}
      >
        <View style={s.modalBackdrop}>
          <View style={s.modalCard}>
            <Text style={s.modalTitle}>
              {picker?.type === 'product' ? 'Seleziona prodotto' :
               picker?.type === 'customer' ? 'Seleziona cliente' :
               'Seleziona socio'}
            </Text>

            <TextInput
              style={s.input}
              value={search}
              onChangeText={setSearch}
              placeholder="Cerca o scrivi un nuovo nome"
              placeholderTextColor={C.muted}
              autoFocus={false}
            />

            <FlatList
              data={options}
              keyExtractor={(item, index) => `${item}-${index}`}
              keyboardShouldPersistTaps="handled"
              style={{ maxHeight: 280 }}
              ListEmptyComponent={
                <Text style={s.empty}>Nessun risultato.</Text>
              }
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={s.optionRow}
                  onPress={() => chooseOption(item)}
                >
                  <Text style={s.optionText}>{item}</Text>
                  <Text style={{ color: C.cyan }}>Seleziona ›</Text>
                </TouchableOpacity>
              )}
            />

            {isCatalog && search.trim() &&
              !options.some(x => x.toLowerCase() === search.trim().toLowerCase()) &&
              (
                <Button
                  title={`Usa: ${search.trim()}`}
                  onPress={() => chooseOption(search.trim())}
                  type="success"
                />
              )}

            <Button
              title="Chiudi"
              type="secondary"
              onPress={() => setPicker(null)}
            />
          </View>
        </View>
      </Modal>
    );
  }

  function header(title, subtitle) {
    return (
      <View style={s.pageHeader}>
        <Text style={s.eyebrow}>POKECHIACCHERE / GESTIONALE</Text>
        <Text style={s.pageTitle}>{title}</Text>
        {!!subtitle && <Text style={s.subtitle}>{subtitle}</Text>}
      </View>
    );
  }

  function section(title) {
    return <Text style={s.sectionTitle}>{title}</Text>;
  }

  function renderHome() {
    return (
      <>
        {header('Dashboard', 'Situazione economica e movimenti')}

        <View style={s.hero}>
          <Text style={s.heroLabel}>VENDITE TOTALI</Text>
          <Text style={s.heroValue}>{money(totals.sales)}</Text>
          <View style={s.separator} />
          <View style={s.heroRow}>
            <Text style={s.mutedText}>Utile dopo tassa stimata</Text>
            <Text style={s.profitValue}>{money(totals.profit)}</Text>
          </View>
        </View>

        <View style={s.grid}>
          <Card title="Commissioni TikTok" value={totals.fees} color={C.red} />
          <Card title="Altri costi" value={totals.other} color={C.yellow} />
          <Card title="Costo merce venduta" value={totals.cost} color={C.cyan} />
          <Card title="Tassa stimata 2%" value={totals.tax} color={C.red} />
        </View>

        {section('01 · GESTIONE MERCE')}
        <View style={s.panel}>
          <Text style={s.panelTitle}>Totale acquisti registrati</Text>
          <Text style={s.panelValue}>{money(totals.purchases)}</Text>
          <View style={s.twoColumns}>
            <View style={s.miniBox}>
              <Text style={s.mutedText}>Anticipato da Poggio</Text>
              <Text style={s.miniValue}>{money(totals.poggioPurchases)}</Text>
            </View>
            <View style={s.miniBox}>
              <Text style={s.mutedText}>Anticipato da Fanton</Text>
              <Text style={s.miniValue}>{money(totals.fantonPurchases)}</Text>
            </View>
          </View>
          <Button
            title="+ Registra acquisto merce"
            onPress={() => openForm('purchaseForm')}
          />
        </View>

        {section('02 · UTILE E CASSA')}
        <View style={s.grid}>
          <Card title="Utile prima della tassa" value={totals.profitBeforeTax} color={C.cyan} />
          <Card title="Utile dopo la tassa" value={totals.profit} color={C.green} />
          <Card title="Quota utile Poggio" value={totals.profit / 2} color={C.cyan} />
          <Card title="Quota utile Fanton" value={totals.profit / 2} color={C.yellow} />
        </View>

        <View style={s.panel}>
          <Text style={s.panelTitle}>Stima cassa residua</Text>
          <Text style={s.panelValue}>{money(totals.cashEstimate)}</Text>
          <Text style={s.mutedSmall}>
            Stima semplificata: non comprende eventuali giacenze iniziali,
            rimborsi o movimenti non registrati.
          </Text>
        </View>

        {section('03 · PRELIEVI E SPETTANZE')}
        <View style={s.grid}>
          <Card title="Prelievi Poggio" value={totals.poggioWithdrawals} color={C.cyan} />
          <Card title="Prelievi Fanton" value={totals.fantonWithdrawals} color={C.yellow} />
          <Card title="Quota utile residua Poggio" value={totals.poggioPosition} color={C.green} />
          <Card title="Quota utile residua Fanton" value={totals.fantonPosition} color={C.green} />
        </View>

        {section('04 · CONGUAGLIO SOCI')}
        <View style={s.panel}>
          <Text style={s.panelTitle}>Saldo indicativo dei movimenti</Text>
          <View style={s.twoColumns}>
            <View style={s.miniBox}>
              <Text style={s.partnerName}>POGGIO</Text>
              <Text style={s.balanceValue}>{money(totals.poggioBalance)}</Text>
            </View>
            <View style={s.miniBox}>
              <Text style={s.partnerName}>FANTON</Text>
              <Text style={s.balanceValue}>{money(totals.fantonBalance)}</Text>
            </View>
          </View>
          <Text style={s.mutedSmall}>
            Il saldo tiene conto degli acquisti anticipati, della quota utile,
            dei prelievi e dei pagamenti interni. Va verificato rispetto alle
            formule del foglio Excel prima di effettuare un conguaglio reale.
          </Text>
          <Button
            title="Apri movimenti tra soci"
            onPress={() => setPage('payments')}
            type="secondary"
          />
        </View>

        {section('05 · OPERAZIONI')}
        <View style={s.actionGrid}>
          <Button title="+ Nuova vendita" onPress={() => openForm('saleForm')} />
          <Button title="+ Nuovo acquisto" onPress={() => openForm('purchaseForm')} />
          <Button title="⇄ Pagamento tra soci" onPress={() => openForm('paymentForm')} type="success" />
          <Button title="↓ Nuovo prelievo" onPress={() => openForm('withdrawalForm')} type="secondary" />
        </View>

        {section('06 · ARCHIVI')}
        <View style={s.actionGrid}>
          <Button title="Prodotti" onPress={() => setPage('products')} type="secondary" />
          <Button title="Clienti" onPress={() => setPage('customers')} type="secondary" />
        </View>
      </>
    );
  }

  function renderSaleForm() {
    const total = num(form.quantity) * num(form.unit_price);
    const cost = num(form.quantity) * num(form.purchase_unit_cost);

    return (
      <>
        {header(editing ? 'Modifica vendita' : 'Nuova vendita', 'Registrazione TikTok Shop')}
        <View style={s.panel}>
          <Field label="Data (GG/MM/AAAA)" value={form.date} onChangeText={v => change('date', v)} placeholder="GG/MM/AAAA" />
          <Field label="Numero ordine" value={form.order_number} onChangeText={v => change('order_number', v)} />
          {dropdown('Cliente', 'customer', 'customer', [form.first_name, form.last_name].filter(Boolean).join(' '), 'Scegli o scrivi un cliente')}
          <Field label="Nome cliente" value={form.first_name} onChangeText={v => change('first_name', v)} />
          <Field label="Cognome cliente" value={form.last_name} onChangeText={v => change('last_name', v)} />
          {dropdown('Prodotto', 'product', 'product', form.product, 'Scegli o scrivi un prodotto')}
          <Field label="Quantità" value={form.quantity} onChangeText={v => change('quantity', v)} keyboardType="decimal-pad" />
          <Field label="Prezzo unitario (€)" value={form.unit_price} onChangeText={v => change('unit_price', v)} keyboardType="decimal-pad" />
          <Field label="Commissioni TikTok (€)" value={form.fees} onChangeText={v => change('fees', v)} keyboardType="decimal-pad" />
          <Field label="Altri costi (€)" value={form.other_costs} onChangeText={v => change('other_costs', v)} keyboardType="decimal-pad" />
          <Field label="Costo unitario merce (€)" value={form.purchase_unit_cost} onChangeText={v => change('purchase_unit_cost', v)} keyboardType="decimal-pad" />

          <View style={s.summary}>
            <Text style={s.summaryLine}>Totale vendita: {money(total)}</Text>
            <Text style={s.summaryLine}>Costo merce: {money(cost)}</Text>
            <Text style={s.summaryLine}>
              Utile prima della tassa: {money(total - cost - num(form.fees) - num(form.other_costs))}
            </Text>
          </View>

          <Button title={editing ? 'Salva modifiche' : 'Salva vendita'} onPress={saveSale} />
          <Button title="Annulla" type="secondary" onPress={() => setPage('sales')} />
        </View>
      </>
    );
  }

  function renderPurchaseForm() {
    return (
      <>
        {header(editing ? 'Modifica acquisto' : 'Acquisto merce', 'Registra chi ha anticipato la spesa')}
        <View style={s.panel}>
          <Field label="Data (GG/MM/AAAA)" value={form.date} onChangeText={v => change('date', v)} placeholder="GG/MM/AAAA" />
          {dropdown('Chi ha pagato', 'partner', 'buyer', form.buyer, 'Seleziona Poggio o Fanton')}
          {dropdown('Prodotto', 'product', 'product', form.product, 'Scegli o scrivi un prodotto')}
          <Field label="Quantità" value={form.quantity} onChangeText={v => change('quantity', v)} keyboardType="decimal-pad" />
          <Field label="Prezzo unitario (€)" value={form.unit_price} onChangeText={v => change('unit_price', v)} keyboardType="decimal-pad" />
          <View style={s.summary}>
            <Text style={s.summaryLine}>
              Totale acquisto: {money(num(form.quantity) * num(form.unit_price))}
            </Text>
          </View>
          <Button
            title={editing ? 'Salva modifiche' : 'Salva acquisto'}
            onPress={savePurchase}
          />
          <Button title="Annulla" type="secondary" onPress={() => setPage('purchases')} />
        </View>
      </>
    );
  }

  function renderPaymentForm() {
    return (
      <>
        {header(editing ? 'Modifica pagamento' : 'Pagamento tra soci', 'Trasferimenti interni')}
        <View style={s.panel}>
          <Field label="Data (GG/MM/AAAA)" value={form.date} onChangeText={v => change('date', v)} placeholder="GG/MM/AAAA" />
          {dropdown('Chi ha pagato', 'partner', 'payer', form.payer, 'Seleziona socio')}
          {dropdown('Chi ha ricevuto', 'receiver', 'receiver', form.receiver, 'Seleziona socio')}
          <Field label="Importo (€)" value={form.amount} onChangeText={v => change('amount', v)} keyboardType="decimal-pad" />
          <Field label="Note" value={form.note} onChangeText={v => change('note', v)} />
          <Button
            title={editing ? 'Salva modifiche' : 'Salva pagamento'}
            onPress={() => {
              if (!form.payer || !form.receiver || form.payer === form.receiver || num(form.amount) <= 0) {
                Alert.alert('Controlla i dati', 'Scegli due soci diversi e un importo maggiore di zero.');
                return;
              }
              saveRecord('internal_payments', {
                payment_date: toDatabaseDate(form.date),
                payer: form.payer,
                receiver: form.receiver,
                amount: num(form.amount),
                note: form.note || ''
              });
            }}
          />
          <Button title="Annulla" type="secondary" onPress={() => setPage('payments')} />
        </View>
      </>
    );
  }

  function renderWithdrawalForm() {
    return (
      <>
        {header(editing ? 'Modifica prelievo' : 'Nuovo prelievo', 'Prelievi personali dei soci')}
        <View style={s.panel}>
          <Field label="Data (GG/MM/AAAA)" value={form.date} onChangeText={v => change('date', v)} placeholder="GG/MM/AAAA" />
          {dropdown('Socio', 'partner', 'person', form.person, 'Seleziona socio')}
          <Field label="Importo (€)" value={form.amount} onChangeText={v => change('amount', v)} keyboardType="decimal-pad" />
          <Field label="Note" value={form.note} onChangeText={v => change('note', v)} />
          <Button
            title={editing ? 'Salva modifiche' : 'Salva prelievo'}
            onPress={() => {
              if (!form.person || num(form.amount) <= 0) {
                Alert.alert('Dati mancanti', 'Seleziona il socio e inserisci l’importo.');
                return;
              }
              saveRecord('withdrawals', {
                withdrawal_date: toDatabaseDate(form.date),
                person: form.person,
                amount: num(form.amount),
                note: form.note || ''
              });
            }}
          />
          <Button title="Annulla" type="secondary" onPress={() => setPage('home')} />
        </View>
      </>
    );
  }

  function renderCatalog(table) {
    const isProduct = table === 'products';
    const data = records[table] || [];

    return (
      <>
        {header(isProduct ? 'Prodotti' : 'Clienti', 'Archivio condiviso')}
        <View style={s.panel}>
          <Text style={s.label}>Posizione del nome nell'elenco</Text>
          <View style={s.filterRow}>
            {['top', 'center', 'bottom'].map(pos => (
              <TouchableOpacity key={pos} style={[s.chip, namePosition === pos && s.chipActive]} onPress={() => setNamePosition(pos)}>
                <Text style={[s.chipText, namePosition === pos && s.chipTextActive]}>{pos === 'top' ? 'Alto' : pos === 'center' ? 'Centro' : 'Basso'}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Field
            label={isProduct ? 'Nome prodotto' : 'Nome e cognome'}
            value={form.name}
            onChangeText={v => change('name', v)}
            placeholder="Inserisci un nome"
          />
          <Button
            title={isProduct ? '+ Aggiungi prodotto' : '+ Aggiungi cliente'}
            onPress={async () => {
              const name = String(form.name || '').trim();
              if (!name) {
                Alert.alert('Nome mancante', 'Scrivi un nome.');
                return;
              }
              setLoading(true);
              try {
                await addCatalog(table, name);
                setForm({});
                Alert.alert('Archivio aggiornato', `${name} è stato aggiunto.`);
              } catch (e) {
                Alert.alert('Errore archivio', e.message);
              } finally {
                setLoading(false);
              }
            }}
          />
        </View>

        {data.map(row => (
          <View key={row.id} style={[s.record, { alignItems: namePosition === 'top' ? 'flex-start' : namePosition === 'bottom' ? 'flex-end' : 'center' }]}>
            <Text style={[s.recordTitle, { flex: 1, textAlignVertical: namePosition === 'top' ? 'top' : namePosition === 'bottom' ? 'bottom' : 'center' }]}>{row.name}</Text>
            <Button title="Elimina" type="danger" onPress={() => deleteRow(table, row)} />
          </View>
        ))}
        {!data.length && <Text style={s.empty}>Nessun elemento registrato.</Text>}
      </>
    );
  }

  function renderList(table) {
    const config = {
      sales: { title: 'Vendite', date: 'sale_date', amount: 'total_sale' },
      purchases: { title: 'Acquisti merce', date: 'purchase_date', amount: null },
      internal_payments: { title: 'Pagamenti soci', date: 'payment_date', amount: 'amount' },
      withdrawals: { title: 'Prelievi', date: 'withdrawal_date', amount: 'amount' }
    }[table];
    const target = {
      sales: 'saleForm', purchases: 'purchaseForm',
      internal_payments: 'paymentForm', withdrawals: 'withdrawalForm'
    }[table];

    const rawData = records[table] || [];
    const getAmount = row => config.amount ? num(row[config.amount]) : num(row.quantity) * num(row.unit_price);
    const getTitle = row => row.product || row.customer_name ||
      ([row.payer, row.receiver].filter(Boolean).length ? `${row.payer || ''} → ${row.receiver || ''}` : '') ||
      row.person || row.buyer || row.order_number || row.note || 'Registrazione';
    const filteredData = rawData.filter(row => {
      const searchable = [getTitle(row), row.customer_name, row.buyer, row.person,
        row.payer, row.receiver, row.order_number, row.note, row.product,
        row[config.date], getAmount(row)].filter(Boolean).join(' ').toLowerCase();
      return searchable.includes(listSearch.trim().toLowerCase());
    }).sort((a, b) => {
      if (sortMode === 'name_asc') return getTitle(a).localeCompare(getTitle(b), 'it', { sensitivity: 'base' });
      if (sortMode === 'name_desc') return getTitle(b).localeCompare(getTitle(a), 'it', { sensitivity: 'base' });
      if (sortMode === 'price_asc') return getAmount(a) - getAmount(b);
      if (sortMode === 'price_desc') return getAmount(b) - getAmount(a);
      if (sortMode === 'date_asc') return dateSortValue(a[config.date]) - dateSortValue(b[config.date]);
      return dateSortValue(b[config.date]) - dateSortValue(a[config.date]);
    });

    return (
      <>
        {header(config.title, 'Registro delle operazioni')}
        <Button title="+ Nuova registrazione" onPress={() => openForm(target)} />
        <View style={s.panel}>
          <Field label="Cerca per nome, data, prezzo o dettaglio" value={listSearch} onChangeText={setListSearch} placeholder="Scrivi per filtrare…" />
          <Text style={s.label}>Ordina per</Text>
          <View style={s.filterWrap}>
            {[
              ['date_desc', 'Data ↓'], ['date_asc', 'Data ↑'],
              ['name_asc', 'Nome A-Z'], ['name_desc', 'Nome Z-A'],
              ['price_asc', 'Prezzo ↑'], ['price_desc', 'Prezzo ↓']
            ].map(([value, label]) => (
              <TouchableOpacity key={value} style={[s.chip, sortMode === value && s.chipActive]} onPress={() => setSortMode(value)}>
                <Text style={[s.chipText, sortMode === value && s.chipTextActive]}>{label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={[s.label, { marginTop: 12 }]}>Visualizzazione</Text>
          <View style={s.filterRow}>
            {['details', 'list'].map(value => (
              <TouchableOpacity key={value} style={[s.chip, listView === value && s.chipActive]} onPress={() => setListView(value)}>
                <Text style={[s.chipText, listView === value && s.chipTextActive]}>{value === 'details' ? 'Dettagli' : 'Elenco compatto'}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={s.mutedSmall}>{filteredData.length} di {rawData.length} registrazioni</Text>
        </View>

        {filteredData.map(row => {
          const amount = getAmount(row);
          const title = getTitle(row);
          const dateText = toItalianDate(row[config.date]);
          const details = [
            row.order_number ? `Ordine ${row.order_number}` : '',
            row.buyer ? `Pagato da ${row.buyer}` : '',
            row.customer_name || '', row.person ? `Socio: ${row.person}` : '',
            row.payer && row.receiver ? `${row.payer} → ${row.receiver}` : '',
            row.quantity != null ? `Quantità: ${row.quantity}` : '',
            row.note || ''
          ].filter(Boolean).join(' · ');
          return (
            <View key={row.id} style={s.record}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={s.recordTitle}>{title}</Text>
                <Text style={s.recordSub}>{dateText}{listView === 'details' && details ? ` · ${details}` : ''}</Text>
                <Text style={s.recordAmount}>{money(amount)}</Text>
              </View>
              <View style={{ width: 100 }}>
                <Button title="Modifica" type="secondary" onPress={() => editRow(table, row)} />
                <Button title="Elimina" type="danger" onPress={() => deleteRow(table, row)} />
              </View>
            </View>
          );
        })}
        {!filteredData.length && <Text style={s.empty}>{rawData.length ? 'Nessun risultato per questi filtri.' : 'Ancora nessuna registrazione.'}</Text>}
      </>
    );
  }

  function navItem(title, icon, target) {
    const active = page === target ||
      (target === 'payments' && page === 'paymentForm') ||
      (target === 'products' && page === 'customers');

    return (
      <TouchableOpacity
        key={target}
        style={s.navItem}
        onPress={() => setPage(target)}
      >
        <Text style={[s.navIcon, active && { color: C.cyan }]}>{icon}</Text>
        <Text style={[s.navLabel, active && { color: C.cyan }]}>{title}</Text>
      </TouchableOpacity>
    );
  }

  if (!sessionReady) {
    return (
      <SafeAreaView style={s.safe}>
        <StatusBar barStyle="light-content" backgroundColor={C.bg} />
        <View style={s.login}><ActivityIndicator color={C.cyan} size="large" /></View>
      </SafeAreaView>
    );
  }

  if (!session) {
    return (
      <SafeAreaView style={s.safe}>
        <StatusBar barStyle="light-content" backgroundColor={C.bg} />
        <View style={s.login}>
          <Text style={s.brand}>POKE<Text style={{ color: C.red }}>CHIACCHIERE</Text></Text>
          <Text style={s.pageTitle}>Bentornato.</Text>
          <Text style={s.subtitle}>Gestionale condiviso</Text>
          <View style={s.panel}>
            <Field label="Email Supabase" value={email} onChangeText={setEmail} />
            <Field label="Password" value={password} onChangeText={setPassword} />
            <Button title={loading ? 'Accesso in corso…' : 'Accedi'} onPress={signIn} />
          </View>
          {loading && <ActivityIndicator color={C.cyan} />}
        </View>
      </SafeAreaView>
    );
  }

  let content;
  if (page === 'home') content = renderHome();
  else if (page === 'saleForm') content = renderSaleForm();
  else if (page === 'purchaseForm') content = renderPurchaseForm();
  else if (page === 'paymentForm') content = renderPaymentForm();
  else if (page === 'withdrawalForm') content = renderWithdrawalForm();
  else if (page === 'products' || page === 'customers') content = renderCatalog(page);
  else if (['sales', 'purchases', 'internal_payments', 'withdrawals'].includes(page)) content = renderList(page);
  else if (page === 'payments') content = renderList('internal_payments');
  else content = renderHome();

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />

      <View style={s.topBar}>
        <View>
          <Text style={s.brand}>POKE<Text style={{ color: C.red }}>CHIACCHIERE</Text></Text>
          <Text style={s.topCaption}>GESTIONALE · LIVE</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <TouchableOpacity style={s.refresh} onPress={loadData}>
            <Text style={s.refreshText}>↻</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.refresh, { width: 62 }]} onPress={signOut}>
            <Text style={[s.buttonText, { color: C.red }]}>Esci</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={s.main}
        contentContainerStyle={s.content}
        keyboardShouldPersistTaps="handled"
      >
        {content}
        {loading && <ActivityIndicator color={C.cyan} style={{ margin: 16 }} />}
      </ScrollView>

      <View style={s.nav}>
        {navItem('Home', '⌂', 'home')}
        {navItem('Vendite', '↗', 'sales')}
        {navItem('Acquisti', '▤', 'purchases')}
        {navItem('Soci', '⇄', 'payments')}
        {navItem('Archivio', '▦', 'products')}
      </View>

      {pickerModal()}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  main: { flex: 1 },
  content: { padding: 17, paddingBottom: 30 },
  topBar: {
    paddingHorizontal: 18, paddingVertical: 16,
    backgroundColor: C.panel, borderBottomWidth: 1,
    borderBottomColor: C.border, flexDirection: 'row',
    justifyContent: 'space-between', alignItems: 'center'
  },
  brand: { fontSize: 17, fontWeight: '900', letterSpacing: 1.1, color: C.white },
  topCaption: { fontSize: 10, color: C.muted, letterSpacing: 2, marginTop: 5 },
  refresh: {
    width: 46, height: 46, borderRadius: 15,
    backgroundColor: C.panel2, alignItems: 'center', justifyContent: 'center'
  },
  refreshText: { fontSize: 27, color: C.cyan },
  pageHeader: { marginBottom: 20 },
  eyebrow: { fontSize: 10, letterSpacing: 2, color: C.cyan, fontWeight: '900', marginBottom: 8 },
  pageTitle: { fontSize: 29, fontWeight: '900', color: C.white },
  subtitle: { fontSize: 14, color: C.muted, marginTop: 7 },
  hero: {
    backgroundColor: C.panel, borderWidth: 1, borderColor: '#315783',
    borderRadius: 22, padding: 22, marginBottom: 15
  },
  heroLabel: { color: C.cyan, fontWeight: '900', letterSpacing: 3, fontSize: 11 },
  heroValue: { color: C.white, fontWeight: '900', fontSize: 36, marginTop: 12 },
  separator: { height: 1, backgroundColor: C.border, marginVertical: 19 },
  heroRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  mutedText: { color: C.muted, fontSize: 12 },
  profitValue: { color: C.green, fontWeight: '900', fontSize: 17 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  metric: {
    width: '48%', minHeight: 118, backgroundColor: C.panel,
    borderRadius: 17, padding: 14, marginBottom: 11,
    borderWidth: 1, borderColor: C.border
  },
  metricLine: { height: 4, width: 34, borderRadius: 4, marginBottom: 14 },
  metricLabel: { color: C.muted, fontSize: 12, lineHeight: 18 },
  metricValue: { color: C.white, fontSize: 17, fontWeight: '900', marginTop: 8 },
  mutedSmall: { color: C.muted, fontSize: 11, lineHeight: 17, marginTop: 9 },
  sectionTitle: {
    color: C.cyan, fontWeight: '900', fontSize: 12,
    letterSpacing: 1.5, marginTop: 20, marginBottom: 12
  },
  panel: {
    backgroundColor: C.panel, borderRadius: 18, padding: 16,
    borderWidth: 1, borderColor: C.border, marginBottom: 13
  },
  panelTitle: { color: C.muted, fontSize: 13, fontWeight: '700' },
  panelValue: { color: C.white, fontSize: 25, fontWeight: '900', marginTop: 8 },
  twoColumns: { flexDirection: 'row', gap: 10, marginTop: 14 },
  miniBox: {
    flex: 1, backgroundColor: C.panel2, padding: 13,
    borderRadius: 13, minWidth: 0
  },
  miniValue: { color: C.white, fontWeight: '900', fontSize: 15, marginTop: 8 },
  partnerName: { color: C.cyan, fontWeight: '900', letterSpacing: 2, fontSize: 11 },
  balanceValue: { color: C.white, fontSize: 18, fontWeight: '900', marginTop: 9 },
  actionGrid: { gap: 4, marginBottom: 12 },
  button: {
    minHeight: 48, paddingHorizontal: 14, paddingVertical: 13,
    borderRadius: 12, backgroundColor: C.blue,
    alignItems: 'center', justifyContent: 'center', marginTop: 8
  },
  buttonSecondary: { backgroundColor: C.panel2, borderWidth: 1, borderColor: '#405674' },
  buttonDanger: { backgroundColor: '#462131', borderWidth: 1, borderColor: C.red },
  buttonSuccess: { backgroundColor: '#123D37', borderWidth: 1, borderColor: C.green },
  buttonText: { color: C.white, fontSize: 13, fontWeight: '900', textAlign: 'center' },
  field: { marginBottom: 13 },
  label: { color: C.muted, fontSize: 12, fontWeight: '800', marginBottom: 7 },
  input: {
    backgroundColor: C.bg, borderRadius: 11, borderWidth: 1,
    borderColor: C.border, paddingHorizontal: 13, paddingVertical: 13,
    color: C.white, fontSize: 15
  },
  dropdown: {
    backgroundColor: C.bg, borderRadius: 11, borderWidth: 1,
    borderColor: C.border, paddingHorizontal: 13, paddingVertical: 15,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'
  },
  dropdownText: { color: C.white, fontSize: 14 },
  chevron: { color: C.cyan, fontSize: 22, fontWeight: '900' },
  summary: { backgroundColor: C.panel2, borderRadius: 12, padding: 14, marginTop: 8 },
  summaryLine: { color: C.white, fontSize: 13, fontWeight: '700', marginVertical: 4 },
  record: {
    backgroundColor: C.panel, borderRadius: 15, padding: 13,
    marginTop: 10, borderWidth: 1, borderColor: C.border,
    flexDirection: 'row', alignItems: 'center', gap: 10
  },
  recordTitle: { color: C.white, fontWeight: '900', fontSize: 13 },
  recordSub: { color: C.muted, fontSize: 10, marginTop: 5 },
  recordAmount: { color: C.green, fontWeight: '900', fontSize: 15, marginTop: 7 },
  empty: { color: C.muted, textAlign: 'center', padding: 20 },
  nav: {
    flexDirection: 'row', justifyContent: 'space-around',
    backgroundColor: C.panel, borderTopWidth: 1,
    borderTopColor: C.border, paddingTop: 10, paddingBottom: 8
  },
  navItem: { alignItems: 'center', flex: 1, paddingVertical: 3 },
  navIcon: { fontSize: 22, color: C.muted, fontWeight: '800' },
  navLabel: { fontSize: 10, color: C.muted, marginTop: 5, fontWeight: '800' },
  modalBackdrop: { flex: 1, backgroundColor: '#000C', justifyContent: 'flex-end' },
  modalCard: {
    backgroundColor: C.panel, borderTopLeftRadius: 24,
    borderTopRightRadius: 24, padding: 20, paddingBottom: 30,
    borderWidth: 1, borderColor: C.border
  },
  modalTitle: { color: C.white, fontSize: 21, fontWeight: '900', marginBottom: 15 },
  optionRow: {
    paddingVertical: 14, borderBottomWidth: 1,
    borderBottomColor: C.border, flexDirection: 'row',
    justifyContent: 'space-between', alignItems: 'center'
  },
  optionText: { color: C.white, fontSize: 14 },
  filterRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginBottom: 6 },
  filterWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  chip: { borderRadius: 10, paddingHorizontal: 11, paddingVertical: 9, backgroundColor: C.panel2, borderWidth: 1, borderColor: C.border },
  chipActive: { backgroundColor: '#123D5D', borderColor: C.cyan },
  chipText: { color: C.muted, fontSize: 11, fontWeight: '800' },
  chipTextActive: { color: C.white },
  login: { flex: 1, justifyContent: 'center', padding: 22 }
});